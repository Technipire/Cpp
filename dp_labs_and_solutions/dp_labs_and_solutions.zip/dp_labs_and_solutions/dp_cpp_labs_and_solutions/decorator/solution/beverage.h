// beverage.h

#ifndef beverage_header
#define beverage_header

class beverage
{
public:
	virtual void prepare() = 0;
};

#endif
