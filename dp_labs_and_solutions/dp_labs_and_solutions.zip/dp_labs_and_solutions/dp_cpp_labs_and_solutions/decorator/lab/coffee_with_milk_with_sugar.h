// coffee_with_milk_with_sugar.h

#ifndef coffee_with_milk_with_sugar_header
#define coffee_with_milk_with_sugar_header

#include "coffee_with_milk.h"

class coffee_with_milk_with_sugar : public coffee_with_milk
{
public:
	virtual void prepare();
};

#endif
