// coffee_with_milk_without_sugar.h

#ifndef coffee_with_milk_without_sugar_header
#define coffee_with_milk_without_sugar_header

#include "coffee_with_milk.h"

class coffee_with_milk_without_sugar : public coffee_with_milk
{
public:
	virtual void prepare();
};

#endif
