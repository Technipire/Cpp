// coffee_with_milk_without_sugar.cpp

#include <iostream>
#include "coffee_with_milk.h"
#include "coffee_with_milk_without_sugar.h"

void coffee_with_milk_without_sugar::prepare()
{
	coffee_with_milk::prepare();
}
