// coffee.h

#ifndef coffee_header
#define coffee_header

class coffee
{
public:
	virtual void prepare() = 0;
};

#endif
