// coffee_without_milk_without_sugar.cpp

#include <iostream>
#include "coffee_without_milk.h"
#include "coffee_without_milk_without_sugar.h"

void coffee_without_milk_without_sugar::prepare()
{
	coffee_without_milk::prepare();
}
