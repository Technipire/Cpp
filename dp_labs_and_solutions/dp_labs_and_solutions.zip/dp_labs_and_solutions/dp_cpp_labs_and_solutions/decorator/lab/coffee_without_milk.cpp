// coffee_without_milk.cpp

#include <iostream>
#include "coffee.h"
#include "coffee_without_milk.h"

void coffee_without_milk::prepare()
{
	coffee::prepare();
}
