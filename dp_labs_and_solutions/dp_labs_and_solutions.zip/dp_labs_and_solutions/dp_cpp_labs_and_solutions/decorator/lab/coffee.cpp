// coffee.cpp

#include <iostream>
#include "coffee.h"

void coffee::prepare()
{
	std::cout << "Brewing coffee.\n";
}
