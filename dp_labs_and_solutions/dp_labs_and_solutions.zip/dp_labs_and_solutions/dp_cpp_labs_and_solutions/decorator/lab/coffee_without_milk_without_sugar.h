// coffee_without_milk_without_sugar.h

#ifndef coffee_without_milk_without_sugar_header
#define coffee_without_milk_without_sugar_header

#include "coffee_without_milk.h"

class coffee_without_milk_without_sugar : public coffee_without_milk
{
public:
	virtual void prepare();
};

#endif
