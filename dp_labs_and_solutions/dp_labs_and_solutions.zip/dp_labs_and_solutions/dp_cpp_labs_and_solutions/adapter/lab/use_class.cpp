// use_class.cpp

#include "table.h"
#include "use_class.h"

void use_class::use(table * a_table)
{
	a_table->display();
}
