// setup_class.h

#ifndef setup_class_header
#define setup_class_header

class address_book;

class setup_class
{
public:
	static address_book * setup();
};

#endif
