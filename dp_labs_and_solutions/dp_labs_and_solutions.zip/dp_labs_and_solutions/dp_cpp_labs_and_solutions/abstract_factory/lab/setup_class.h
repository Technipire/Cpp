// setup_class.h

#ifndef setup_class_header
#define setup_class_header

#include "setup_class.h"
class garden;

class setup_class
{
public:
	static garden * setup();
};

#endif
