// tomato.cpp

#include "tomato.h"

tomato::tomato(double a_price)
{
	my_price = a_price;
}

tomato::~tomato()
{
}
