// tomato.h

#ifndef tomato_header
#define tomato_header

class tomato
{
public:
	tomato(double a_price);
	virtual ~tomato();

private:
	double my_price;
};

#endif
