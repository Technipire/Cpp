// right_angled_quadrilateral_body.cpp

#include "right_angled_quadrilateral_body.h"
