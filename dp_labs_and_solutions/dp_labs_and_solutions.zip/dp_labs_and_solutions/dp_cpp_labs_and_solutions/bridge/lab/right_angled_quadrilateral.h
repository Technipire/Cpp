// right_angled_quadrilateral.h

#ifndef right_angled_quadrilateral_header
#define right_angled_quadrilateral_header

class right_angled_quadrilateral
{
};

#endif
