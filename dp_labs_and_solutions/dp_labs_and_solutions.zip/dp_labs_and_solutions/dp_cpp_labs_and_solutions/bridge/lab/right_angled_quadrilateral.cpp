// right_angled_quadrilateral.cpp

#include "right_angled_quadrilateral.h"
