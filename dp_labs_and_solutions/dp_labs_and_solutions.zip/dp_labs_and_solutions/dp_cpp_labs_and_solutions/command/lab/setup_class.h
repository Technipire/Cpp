// setup_class.h

#ifndef setup_class_header
#define setup_class_header

class command;

class setup_class
{
public:
	static command * setup();
};

#endif
