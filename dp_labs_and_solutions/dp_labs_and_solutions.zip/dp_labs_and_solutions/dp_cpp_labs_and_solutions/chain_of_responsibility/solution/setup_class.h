// setup_class.h

#ifndef setup_class_header
#define setup_class_header

class handler;

class setup_class
{
public:
	static handler * setup();
};

#endif
