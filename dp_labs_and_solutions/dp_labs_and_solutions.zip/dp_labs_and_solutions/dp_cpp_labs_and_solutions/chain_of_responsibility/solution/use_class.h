// use_class.h

#ifndef use_class_header
#define use_class_header

class customer_requests_discount_event;
class handler;

class use_class
{
public:
	static void use(customer_requests_discount_event * a_customer_requests_discount_event, handler * a_handler);
};

#endif
