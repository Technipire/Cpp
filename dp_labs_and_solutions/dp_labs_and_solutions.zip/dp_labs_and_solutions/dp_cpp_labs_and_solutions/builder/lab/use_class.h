// use_class.h

#ifndef use_class_header
#define use_class_header

class journey;

class use_class
{
public:
	static void use(journey * a_journey);
};

#endif
