// journey_parser.h

#ifndef journey_parser_header
#define journey_parser_header

class journey_builder;

class journey_parser
{
public:
	void parse(journey_builder & a_journey_builder);
};

#endif
