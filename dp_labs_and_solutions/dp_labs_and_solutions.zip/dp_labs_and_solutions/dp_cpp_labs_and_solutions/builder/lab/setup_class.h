// setup_class.h

#ifndef setup_class_header
#define setup_class_header

class journey;

class setup_class
{
public:
	static journey * setup();
};

#endif
