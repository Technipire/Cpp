// use_class.h

#ifndef use_class_header
#define use_class_header

class lettuce;

class use_class
{
public:
	static void use(lettuce * a_lettuce);
};

#endif
