// setup_class.h

#ifndef setup_class_header
#define setup_class_header

class lettuce;

class setup_class
{
public:
	static lettuce * setup();
};

#endif
